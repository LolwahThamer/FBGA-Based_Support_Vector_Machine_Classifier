module svm_core (clk, rst, start, x_data, y_data, threshold_x, threshold_y, y_calc, mode, result);

input wire clk,rst, start;
input wire [7:0] x_data, y_data, threshold_x, threshold_y;
input wire [15:0] y_calc;
input wire [1:0] mode;
output reg result;

    always @(posedge clk or negedge rst) begin
        if (!rst) begin
            result <= 1'b0;
        end else if (start) begin
            case (mode)
                2'b00: result <= (x_data >= threshold_x) ? 1'b1 : 1'b0; // Vertical mode
                2'b01: result <= (y_data >= threshold_y) ? 1'b1 : 1'b0; // Horizontal mode
                2'b10: result <= (y_data >= y_calc) ? 1'b1 : 1'b0;       // Inclined mode
                default: result <= 1'b0;
            endcase
        end
    end
endmodule
