module output_writer ( clk, rst, start,result,idx);

input wire clk,rst, start, result;
input wire [7:0] idx;
reg [7:0] result_mem [0:255]; 
integer i;

    initial begin
        for (i = 0; i < 256; i = i + 1) begin
            result_mem[i] = 8'b0;
        end
    end

    always @(posedge clk or negedge rst) begin
        if (!rst) begin
            for (i = 0; i < 256; i = i + 1) begin
                result_mem[i] <= 8'b0;
            end
        end else if (start) begin
            result_mem[idx] <= {7'b0, result};
        end
    end

    always @(posedge clk) begin
        if (start) begin
            $writememh("D:/CodeGenerated/DE2_115/new_Asic/new_Asic/Project_ASIC/result.txt", result_mem);  
        end
    end
endmodule

