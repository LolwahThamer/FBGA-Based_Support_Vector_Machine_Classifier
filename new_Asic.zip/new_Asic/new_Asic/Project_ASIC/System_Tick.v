module System_Tick (Clock, Reset_n, tick); 
parameter n = 25; 
parameter [n-1:0] k = 25000000; 
input Clock, Reset_n; 
output reg tick; 
reg [n-1:0] Q; 

always @(posedge Clock or negedge Reset_n)
    begin if (!Reset_n) 
        begin Q <= 1'd0; 
        tick <= 1'd0; 
    end else if (Q==k-1) 
        begin Q <= 1'd0; 
        tick <= 1'd1; 
    end else begin Q <= Q + 1'b1; 
        tick <= 1'd0; 
    end 
end 
endmodule
