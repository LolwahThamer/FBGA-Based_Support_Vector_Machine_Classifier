module svm_system (clk,rst,start,En,mode,done,leds,result,X0, X1, Y0, Y1,X_th0, X_th1, Y_th0, Y_th1,LED,y_calc0);

input wire clk,rst,start,En; 
input wire [1:0] mode;
output wire done; 
output wire [2:0] leds;
output wire result,LED;
output [6:0] X0, X1, Y0, Y1;
output [6:0] X_th0, X_th1, Y_th0, Y_th1; 
output [8:0] y_calc0;
wire [7:0] x_data, y_data, x_threshold, y_threshold;
wire [15:0] y_calc;
wire [7:0] idx;
wire tick;



Counter u6(.clk(tick), .rst(rst), .En(En), .Q(idx));

input_reader u1 (.clk(tick), .rst(rst), .start(start), .x_data(x_data), .y_data(y_data), .done(done),.LED(LED), .idx(idx));

mode_selector u2 (.mode(mode),.x(x_data),.x_threshold(x_threshold), 
        .y_threshold(y_threshold),.y_calc(y_calc));

svm_core u3 (.clk(clk),.rst(rst),.start(start),.x_data(x_data),.y_data(y_data), 
        .threshold_x(x_threshold),.threshold_y(y_threshold),.y_calc(y_calc), 
        .mode(mode),.result(result));

output_writer u4 (.clk(clk),.rst(rst),.start(start),.result(result),.idx(x_data));

output_interface u5 (.result(result),.mode(mode),.leds(leds));

SEG7_LUT HEX0_Display(
    .oSEG(X0),
    .iDIG(x_data[3:0])
);

SEG7_LUT HEX1_Display(
    .oSEG(X1),
    .iDIG(x_data[7:4])
);

SEG7_LUT HEX2_Display(
    .oSEG(Y0),
    .iDIG(y_data[3:0])
);

SEG7_LUT HEX3_Display(
    .oSEG(Y1),
    .iDIG(y_data[7:4])
);

SEG7_LUT HEX4_Display(
    .oSEG(X_th0),
    .iDIG(x_threshold[3:0])
);

SEG7_LUT HEX5_Display(
    .oSEG(X_th1),
    .iDIG(x_threshold[7:4])
);

SEG7_LUT HEX6_Display(
    .oSEG(Y_th0),
    .iDIG(y_threshold[3:0])
);

SEG7_LUT HEX7_Display(
    .oSEG(Y_th1),
    .iDIG(y_threshold[7:4])
);

System_Tick tick_gen (
    .Clock(clk), 
    .Reset_n(rst), 
    .tick(tick)
);

assign y_calc0 = y_calc[8:0];

endmodule

`timescale 1ns / 1ns

module tb_svm_system;

reg clk, rst, start,En;
wire done;
wire [7:0] idx;

//svm_system DUT (.clk(clk),.rst(rst),.start(start),.mode(2'b00),.done(done));
//svm_system DUT (.clk(clk),.rst(rst),.start(start),.mode(2'b01),.done(done));
svm_system DUT (.clk(clk),.rst(rst),.start(start),.mode(2'b10),.done(done));

always #5 clk = ~clk;

initial begin
    clk = 0;
    rst = 1;
	 En = 1;
    start = 0;

    #10 rst = 0;
    #10 start = 1;
	 #10 En = 1;

    wait(done);  
    $display("Simulation completed. Results written to result.txt.");
    $stop;
end
endmodule
