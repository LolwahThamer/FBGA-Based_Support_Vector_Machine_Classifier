module output_interface ( result, mode,leds);

input wire result;
input wire [1:0] mode;
output reg [2:0] leds;

    always @(*) begin
        leds = 3'b000;
        case (mode)
            2'b00: leds[0] = result;  // LED 0 for vertical mode
            2'b01: leds[1] = result;  // LED 1 for horizontal mode
            2'b10: leds[2] = result;  // LED 2 for inclined mode
        endcase
    end

endmodule
