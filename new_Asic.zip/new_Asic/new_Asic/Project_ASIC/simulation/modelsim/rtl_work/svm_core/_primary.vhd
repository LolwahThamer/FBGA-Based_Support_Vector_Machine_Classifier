library verilog;
use verilog.vl_types.all;
entity svm_core is
    port(
        clk             : in     vl_logic;
        rst             : in     vl_logic;
        start           : in     vl_logic;
        x_data          : in     vl_logic_vector(7 downto 0);
        y_data          : in     vl_logic_vector(7 downto 0);
        threshold_x     : in     vl_logic_vector(7 downto 0);
        threshold_y     : in     vl_logic_vector(7 downto 0);
        y_calc          : in     vl_logic_vector(15 downto 0);
        mode            : in     vl_logic_vector(1 downto 0);
        result          : out    vl_logic
    );
end svm_core;
