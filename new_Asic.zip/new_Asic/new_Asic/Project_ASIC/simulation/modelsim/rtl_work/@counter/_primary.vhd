library verilog;
use verilog.vl_types.all;
entity Counter is
    generic(
        n               : integer := 8
    );
    port(
        clk             : in     vl_logic;
        rst             : in     vl_logic;
        En              : in     vl_logic;
        Q               : out    vl_logic_vector
    );
    attribute mti_svvh_generic_type : integer;
    attribute mti_svvh_generic_type of n : constant is 1;
end Counter;
