library verilog;
use verilog.vl_types.all;
entity output_interface is
    port(
        result          : in     vl_logic;
        mode            : in     vl_logic_vector(1 downto 0);
        leds            : out    vl_logic_vector(2 downto 0)
    );
end output_interface;
