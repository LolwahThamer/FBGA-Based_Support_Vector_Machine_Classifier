library verilog;
use verilog.vl_types.all;
entity input_reader is
    port(
        clk             : in     vl_logic;
        rst             : in     vl_logic;
        start           : in     vl_logic;
        x_data          : out    vl_logic_vector(7 downto 0);
        y_data          : out    vl_logic_vector(7 downto 0);
        done            : out    vl_logic;
        LED             : out    vl_logic;
        idx             : in     vl_logic_vector(7 downto 0)
    );
end input_reader;
