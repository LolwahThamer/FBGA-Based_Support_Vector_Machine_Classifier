library verilog;
use verilog.vl_types.all;
entity mode_selector is
    port(
        mode            : in     vl_logic_vector(1 downto 0);
        x               : in     vl_logic_vector(7 downto 0);
        x_threshold     : out    vl_logic_vector(7 downto 0);
        y_threshold     : out    vl_logic_vector(7 downto 0);
        y_calc          : out    vl_logic_vector(15 downto 0)
    );
end mode_selector;
