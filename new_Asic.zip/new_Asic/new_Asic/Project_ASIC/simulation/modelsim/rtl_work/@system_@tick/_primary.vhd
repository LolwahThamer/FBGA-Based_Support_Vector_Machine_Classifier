library verilog;
use verilog.vl_types.all;
entity System_Tick is
    generic(
        n               : integer := 25;
        k               : vl_logic_vector
    );
    port(
        Clock           : in     vl_logic;
        Reset_n         : in     vl_logic;
        tick            : out    vl_logic
    );
    attribute mti_svvh_generic_type : integer;
    attribute mti_svvh_generic_type of n : constant is 1;
    attribute mti_svvh_generic_type of k : constant is 4;
end System_Tick;
