library verilog;
use verilog.vl_types.all;
entity output_writer is
    port(
        clk             : in     vl_logic;
        rst             : in     vl_logic;
        start           : in     vl_logic;
        result          : in     vl_logic;
        idx             : in     vl_logic_vector(7 downto 0)
    );
end output_writer;
