library verilog;
use verilog.vl_types.all;
entity tb_input_reader is
end tb_input_reader;
