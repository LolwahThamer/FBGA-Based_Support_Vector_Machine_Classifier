library verilog;
use verilog.vl_types.all;
entity svm_system is
    port(
        clk             : in     vl_logic;
        rst             : in     vl_logic;
        start           : in     vl_logic;
        En              : in     vl_logic;
        mode            : in     vl_logic_vector(1 downto 0);
        done            : out    vl_logic;
        leds            : out    vl_logic_vector(2 downto 0);
        result          : out    vl_logic;
        X0              : out    vl_logic_vector(6 downto 0);
        X1              : out    vl_logic_vector(6 downto 0);
        Y0              : out    vl_logic_vector(6 downto 0);
        Y1              : out    vl_logic_vector(6 downto 0);
        X_th0           : out    vl_logic_vector(6 downto 0);
        X_th1           : out    vl_logic_vector(6 downto 0);
        Y_th0           : out    vl_logic_vector(6 downto 0);
        Y_th1           : out    vl_logic_vector(6 downto 0);
        LED             : out    vl_logic;
        y_calc0         : out    vl_logic_vector(8 downto 0)
    );
end svm_system;
