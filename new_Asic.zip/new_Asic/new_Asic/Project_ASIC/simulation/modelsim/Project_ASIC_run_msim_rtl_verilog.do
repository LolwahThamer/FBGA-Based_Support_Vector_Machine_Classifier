transcript on
if {[file exists rtl_work]} {
	vdel -lib rtl_work -all
}
vlib rtl_work
vmap work rtl_work

vlog -vlog01compat -work work +incdir+D:/CodeGenerated/DE2_115/new_Asic/new_Asic/Project_ASIC {D:/CodeGenerated/DE2_115/new_Asic/new_Asic/Project_ASIC/mode_selector.v}
vlog -vlog01compat -work work +incdir+D:/CodeGenerated/DE2_115/new_Asic/new_Asic/Project_ASIC {D:/CodeGenerated/DE2_115/new_Asic/new_Asic/Project_ASIC/output_writer.v}
vlog -vlog01compat -work work +incdir+D:/CodeGenerated/DE2_115/new_Asic/new_Asic/Project_ASIC {D:/CodeGenerated/DE2_115/new_Asic/new_Asic/Project_ASIC/output_interface.v}
vlog -vlog01compat -work work +incdir+D:/CodeGenerated/DE2_115/new_Asic/new_Asic/Project_ASIC {D:/CodeGenerated/DE2_115/new_Asic/new_Asic/Project_ASIC/svm_core.v}
vlog -vlog01compat -work work +incdir+D:/CodeGenerated/DE2_115/new_Asic/new_Asic/Project_ASIC {D:/CodeGenerated/DE2_115/new_Asic/new_Asic/Project_ASIC/svm_system.v}
vlog -vlog01compat -work work +incdir+D:/CodeGenerated/DE2_115/new_Asic/new_Asic/Project_ASIC {D:/CodeGenerated/DE2_115/new_Asic/new_Asic/Project_ASIC/SEG7_LUT.v}
vlog -vlog01compat -work work +incdir+D:/CodeGenerated/DE2_115/new_Asic/new_Asic/Project_ASIC {D:/CodeGenerated/DE2_115/new_Asic/new_Asic/Project_ASIC/Counter.v}
vlog -vlog01compat -work work +incdir+D:/CodeGenerated/DE2_115/new_Asic/new_Asic/Project_ASIC {D:/CodeGenerated/DE2_115/new_Asic/new_Asic/Project_ASIC/System_Tick.v}
vlog -vlog01compat -work work +incdir+D:/CodeGenerated/DE2_115/new_Asic/new_Asic/Project_ASIC {D:/CodeGenerated/DE2_115/new_Asic/new_Asic/Project_ASIC/input_reader.v}

