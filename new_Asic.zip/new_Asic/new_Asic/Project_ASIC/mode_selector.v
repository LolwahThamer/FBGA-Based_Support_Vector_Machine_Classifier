module mode_selector ( mode, x, x_threshold, y_threshold, y_calc);

	 input wire [1:0] mode;
    input wire [7:0] x;
    output reg [7:0] x_threshold, y_threshold;
    output reg [15:0] y_calc;
	 
    localparam [7:0] x_fixed_threshold = 8'd128;
    localparam [7:0] y_fixed_threshold = 8'd100;
    localparam [7:0] m = 8'd1;
    localparam [7:0] c = 8'd20;

    always @(*) begin
        case (mode)
            2'b00: begin  // Vertical mode
                x_threshold = x_fixed_threshold;
                y_threshold = 8'b0;
                y_calc = 16'b0;
            end
            2'b01: begin  // Horizontal mode
                x_threshold = 8'b0;
                y_threshold = y_fixed_threshold;
                y_calc = 16'b0;
            end
            2'b10: begin  // Inclined mode
                x_threshold = 8'b0;
                y_threshold = 8'b0;
                y_calc = (m * x) + c;
					 $display("Debug: y_calc = %h for x = %h, m = %h, c = %h", y_calc, x, m, c);
            end
            default: begin
                x_threshold = 8'b0;
                y_threshold = 8'b0;
                y_calc = 16'b0;
            end
        endcase
    end

endmodule
