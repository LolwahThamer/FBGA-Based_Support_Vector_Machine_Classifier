module Counter(clk, rst, En, Q);
parameter n=8;
input clk, rst, En;
output reg [n-1:0] Q;

always@(posedge clk, negedge rst)
    if(!rst)
        Q <= 0;
    else if(En)
        Q <= Q+1'b1;
endmodule
