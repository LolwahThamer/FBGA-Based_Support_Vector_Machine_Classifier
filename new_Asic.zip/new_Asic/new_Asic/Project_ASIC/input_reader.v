module input_reader (clk, rst,start, x_data,y_data,done,LED,idx );
input wire clk,rst, start;
output  reg LED;
output reg [7:0] x_data,y_data;
output reg done;

reg [7:0] x_mem [0:255],y_mem [0:255]; 
input[7:0] idx;           
reg[7:0] Q;

initial begin
    $readmemh("D:/CodeGenerated/DE2_115/new_Asic/new_Asic/Project_ASIC/x_value.txt", x_mem);
	 $readmemh("D:/CodeGenerated/DE2_115/new_Asic/new_Asic/Project_ASIC/y_value.txt", y_mem);

    $display("Debug: Memory Initialization");
    $display("x_mem[0]: %h, y_mem[0]: %h", x_mem[0], y_mem[0]);
    $display("x_mem[255]: %h, y_mem[255]: %h", x_mem[255], y_mem[255]);
end

always @(posedge clk, negedge rst) begin
    if (!rst) begin
        //idx <= 8'd0;
        x_data <= 8'b0;
        y_data <= 8'b0;
        done <= 1'b0;
		  LED <= 1;
        $display("Reset asserted: idx reset to %d", idx);
    end else if (start && !done) begin
        x_data <= x_mem[idx];
        y_data <= y_mem[idx];
        $display("Index: %d, X: %h, Y: %h", idx, x_data, y_data);
        if (idx == 8'd255) begin
            done <= 1'b1;
            $display("Done signal asserted at index %d", idx);
        end else begin
				LED <= 0;
            //idx <= idx + 1'b1;
        end
    end
end



endmodule

`timescale 1ns / 1ns

module tb_input_reader;

reg clk, rst, start;
wire [7:0] x_data, y_data;
wire done;

    input_reader DUT (
        .clk(clk),
        .rst(rst),
        .start(start),
        .x_data(x_data),
        .y_data(y_data),
        .done(done)
    );

    always #5 clk = ~clk;  

    initial begin
        clk = 0;
        rst = 1;
        start = 0;

        #10 rst = 0; 
        #10 start = 1; 

        wait(done);

        $stop;
    end

    initial begin
        $monitor("Time: %0t | x_data: %h | y_data: %h | idx: %d | done: %b", 
                 $time, x_data, y_data, DUT.idx, done);
    end

endmodule
